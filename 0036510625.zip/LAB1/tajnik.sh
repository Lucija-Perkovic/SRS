#!/bin/bash

# Kompajliraj kod
python tajnik.py

# Daj ovlasti
chmod u+x tajnik.sh

# Pokreni main
./tajnik